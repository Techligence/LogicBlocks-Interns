export const MoveSpriteBlock = `
  <category name="Motion" colour="#5C81A6" categorystyle="math_category">
    <block type="move_sprite_10px"></block>
  </category>
`;


