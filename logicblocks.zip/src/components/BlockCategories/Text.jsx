// TextCategory.jsx
export const Text = `
  <category name="Text" colour="#5C81A6" categorystyle="text_category">
    <block type="text"></block>
    <block type="text_print"></block>
  </category>
`;
