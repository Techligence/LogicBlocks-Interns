// LogicCategory.jsx
export const Logic = `
  <category name="Logic" cssclass="logicCategory">
    <block type="controls_if"></block>
  </category>
`;
